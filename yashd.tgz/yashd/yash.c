#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <poll.h>
#include <signal.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define PORT 3820

// CTRL-C and CTRL-Z handlers
static int sock = -1;
static void on_sigint(int sig) {
  (void)sig;
  send(sock, "CTL c\n", 6, MSG_NOSIGNAL);
}
static void on_sigtstp(int sig) {
  (void)sig;
  send(sock, "CTL z\n", 6, MSG_NOSIGNAL);
}

// send every byte of the message, even send() writes only part
static int send_all(int fd, const char *data, size_t length) {
  size_t sent = 0;
  while (sent < length) {
    ssize_t n = send(fd, data + sent, length - sent, MSG_NOSIGNAL);
    if (n > 0) {
      sent += (size_t)n;
    } else if (n == -1 && errno == EINTR) {
      continue;
    } else {
      return -1;
    }
  }
  return 0;
}

int main(int argc, char *argv[]) {
  if (argc != 2) {
    fprintf(stderr, "usage: %s <ip>\n", argv[0]);
    exit(1);
  }

  // server_fd contains socket file descriptor & socket creates the IPv4 TCP
  // socket
  int server_fd = socket(AF_INET, SOCK_STREAM, 0);
  if (server_fd == -1) {
    perror("socket");
    exit(EXIT_FAILURE);
  }

  // socket setup
  struct sockaddr_in server_addr;        // holds server's address
  server_addr = (struct sockaddr_in){0}; // IPv4 address structure
  server_addr.sin_family = AF_INET;      // Which address family that is used
  server_addr.sin_port = htons(PORT);    // defined port
  if (inet_pton(AF_INET, argv[1], &server_addr.sin_addr) != 1) {
    fprintf(stderr, "bad ip: %s\n", argv[1]);
    close(server_fd);
    exit(EXIT_FAILURE);
  }

  // connect to server
  if (connect(server_fd, (struct sockaddr *)&server_addr,
              sizeof server_addr) == -1) { // blocks until accepted
    perror("connect");
    close(server_fd);
    exit(EXIT_FAILURE);
  }

  // CTRL-C and CTRL-Z
  sock = server_fd;
  signal(SIGINT, on_sigint);
  signal(SIGTSTP, on_sigtstp);

  struct pollfd fds[2] = {
      // stdin: watched once the server's first prompt arrives
      {.fd = -1, .events = POLLIN},
      {.fd = server_fd, .events = POLLIN},
  };

  // main loop
  char line[256], cmd[300], buf[1024];
  bool busy = false;
  bool stdin_closed = false;
  char prev = 0, last = 0;

  while (1) {
    if (poll(fds, 2, -1) == -1) {
      if (errno == EINTR)
        continue;
      perror("poll");
      break;
    }

    // server sent something
    if (fds[1].revents & (POLLIN | POLLHUP)) {
      ssize_t n = recv(server_fd, buf, sizeof buf, 0);
      if (n <= 0)
        break;
      fwrite(buf, 1, n, stdout);
      fflush(stdout);
      // handle a prompt split across two recv calls
      for (ssize_t i = 0; i < n; i++) {
        prev = last;
        last = buf[i];
      }
      if (prev == '\n' && last == '#') {
        busy = false;
        // stdin already closed: nothing left to send, so quit
        if (stdin_closed)
          break;
        // a prompt has arrived, so the keyboard can be read now
        fds[0].fd = STDIN_FILENO;
      }
    }

    // keyboard loop
    if (fds[0].revents & (POLLIN | POLLHUP)) {
      // get stdin and check for Ctrl-D (NULL)
      if (fgets(line, sizeof line, stdin) == NULL) {
        if (!busy)
          break;
        // CTRL-D while a command runs
        clearerr(stdin);
        if (send_all(server_fd, "CTL d\n", 6) == -1) {
          perror("send");
          exit(EXIT_FAILURE);
        }
        // pipe or hung-up terminal: no more input is coming, so stop
        // watching stdin and quit once this command's prompt arrives
        if (fds[0].revents & POLLHUP) {
          fds[0].fd = -1;
          stdin_closed = true;
        }
        continue;
      }
      if (busy) {
        if (send_all(server_fd, line, strlen(line)) == -1) {
          perror("send");
          exit(EXIT_FAILURE);
        }
        continue;
      }
      // drop the newline
      line[strcspn(line, "\n")] = '\0';
      if (strcmp(line, "quit") == 0)
        break;
      // send
      int len = snprintf(cmd, sizeof cmd, "CMD %s\n", line);
      if (send_all(server_fd, cmd, len) == -1) {
        perror("send");
        exit(EXIT_FAILURE);
      }
      busy = true;
    }
  }

  printf("\n");
  close(server_fd);
}
